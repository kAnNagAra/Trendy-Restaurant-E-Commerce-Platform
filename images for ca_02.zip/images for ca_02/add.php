<?php

$server = "localhost";
$username = "root";
$password="";
$name_database = "web_ca_2";

$con = mysqli_connect($server,$username,$password,$name_database);

if (!$con){
    die("Failed to connect with database: " . mysqli_connect_error());
}
// database connection code
// $con = mysqli_connect('localhost', 'database_user', 'database_password','database');

$con = mysqli_connect('localhost', 'root', '', 'web_ca_2');

if (!$con) {
    die("Failed to connect with database: " . mysqli_connect_error());
}

// get the post records
$tablename = "signup";

// database insert SQL code
$sql = "INSERT INTO $tablename (name, email, password) 
        VALUES ('$_POST[name]', '$_POST[email]', '$_POST[password]')";

// insert in database
$rs = mysqli_query($con, $sql);

if ($rs) {
    echo "<script>
    alert('Incorrect Password. Try again!');
    window.location.href = 'http://localhost/21it0483/images%20for%20ca_02/signup.php';
    </script>";
    
   // header("Location: images for ca_02\login.html");
} else {
    echo "<script>
    alert('Incorrect Password. Try again!');
    window.location.href = 'http://localhost/21it0483/images%20for%20ca_02/signup.php';
    </script>";
}


// close connection
mysqli_close($con);
?>
