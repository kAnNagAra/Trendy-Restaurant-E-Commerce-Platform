<?php

$server = "localhost";
$username = "root";
$password="";
$name_database = "web_ca_2";

$con = mysqli_connect($server,$username,$password,$name_database);

if (!$con){
    die("Failed to connect with database: " . mysqli_connect_error());
}
// database connection code
// $con = mysqli_connect('localhost', 'database_user', 'database_password','database');

$con = mysqli_connect('localhost', 'root', '', 'web_ca_2');

if (!$con) {
    die("Failed to connect with database: " . mysqli_connect_error());
}

// get the post records
$tablename = "checkout";

// database insert SQL code
$sql = "INSERT INTO $tablename (full_name, email, address, city, name_on_card, Credit_card_num, exp_month, exp_year, cvv) 
        VALUES ('$_POST[full_name]', '$_POST[email]', '$_POST[address]','$_POST[city]','$_POST[name_on_card]','$_POST[Credit_card_num]', '$_POST[exp_month]','$_POST[exp_year]','$_POST[cvv]')";

// insert in database
$rs = mysqli_query($con, $sql);

if ($rs) {
    echo "<script>
    window.location.href = 'http://localhost/21it0483/images%20for%20ca_02/Checkout.php';
    
    </script>";
    
   
} else {
    echo "alert('Incorrect Password. Try again!')";

}


// close connection
mysqli_close($con);
?>
