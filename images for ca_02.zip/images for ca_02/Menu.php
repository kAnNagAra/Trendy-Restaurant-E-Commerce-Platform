<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="Menu.css">
</head>
<body class="">
    <div class="top">
            
        <!---------------Navbar------------------------------------>
            <div class="box">
              <ul type="none">
                <li><a href="Home.html">Home</a></li>
                <li><a href="About.html">About us</a></li>
                <li><a href="Menu.html">Food Menu</a></li>
                <li><a href="http://localhost/21it0483/images%20for%20ca_02/signup.php">Login</a></li>
                 <!-- Add this line -->
                <li><a href="Contact.html">Contact us</a></li>
              </ul>
            </div>
    </div>
    
    <div class="container">
        <header>
            <h1>Food Menu</h1>
            <div class="shopping">
                <img src="cart2.svg">
                <span class="quantity">0</span>
            </div>
        </header>

        <div class="list">
          
        </div>
    </div>
    <div class="cart">
        <h1>Cart</h1>
        <ul class="listCart">
        </ul>
        <div class="checkOut">
            <div class="total">0</div>
            <div class="closeShopping">Close</div>
            <a href="login.html" >
                <button class="btn1" >Place Oder</button></a>
        </div>
    </div>

    <script src="Menu.js"></script>
</body>
</html>