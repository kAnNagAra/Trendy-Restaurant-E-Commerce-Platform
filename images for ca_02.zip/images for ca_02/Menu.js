
let openShopping = document.querySelector('.shopping');
let closeShopping = document.querySelector('.closeShopping');
let list = document.querySelector('.list');
let listCart = document.querySelector('.listCart');
let body = document.querySelector('body');
let total = document.querySelector('.total');
let quantity = document.querySelector('.quantity');

openShopping.addEventListener('click', ()=>{
    body.classList.add('active');
})
closeShopping.addEventListener('click', ()=>{
    body.classList.remove('active');
})

let products = [
    {
        id: 1,
        name: 'Tripple chicken pizza',
        image: 'pitza01.jpg',
        price:1190
    },
    {
        id: 2,
        name: 'Chilli chicken pizza',
        image: 'pitza02.jpg',
        price: 1200
    },
    {
        id: 3,
        name: 'Devilled mackerel pizza',
        image: 'pitza03.jpg',
        price:1250
    },
    {
        id: 4,
        name: 'Sausage delight pizza',
        image: 'pitza04.jpg',
        price: 1090
    },
    {
        id: 5,
        name: 'Cheesy tomato with green chilli pizza',
        image: 'pitza06.jpg',
        price: 1480
    },
    {
        id: 6,
        name: 'Vegi supreme pizza',
        image: 'pitza08.jpg',
        price: 990
    },
    {
        id: 7,
        name: ' Pasta with tomato ketchup',
        image: 'pas1.jpg',
        price:1090.00
    },
    {
        id: 8,
        name: 'Chilli & cheese pasta',
        image: 'pasta2.jpg',
        price: 1200.00
    },
    {
        id:9,
        name: 'Baked pasta with Cheese',
        image: 'pasta3.jpg',
        price:1500.00
    },
    {
        id: 10,
        name: ' Avacado Toste with omlet',
        image: 'ava2.jpg',
        price:1000.00
    },
    {
        id: 11,
        name: 'Avacado Toste',
        image: 'ava.jpg',
        price: 880.00
    },
    {
        id: 12,
        name: 'Sushi Burritos',
        image: 'sushi2.jpeg',
        price:2500.00
    },
    {
        id: 13,
        name: ' Acai Bowl with honey',
        image: 'acai2.jpg',
        price:1000.00
    },
    {
        id: 14,
        name: 'Acai Bowl without honey',
        image: 'acai.jpg',
        price: 990.00
    },
    {
        id: 15,
        name: 'Quinoa Bowl',
        image: 'Quin2.jpg',
        price:1500.00
    },
    {
        id: 16,
        name: 'Laksa with eggs',
        image: 'laksa.jpg',
        price:1150.00
    },
    {
        id: 17,
        name: 'Tacos with vegi filling',
        image: 'tacos2.jpg',
        price: 1550.00
    },
    {
        id: 18,
        name: 'Chiken Burger',
        image: 'bur1.jpg',
        price:880.00
    },
    {
        id: 19,
        name: 'Fries',
        image: 'fries1.jpg',
        price:250.00
    },
    {
        id: 20,
        name: ' Burger combo',
        image: 'Bur3.jpg',
        price: 2550.00
    },
    {
        id: 21,
        name: 'Acai Bowl supreme',
        image: 'acai3.jpg',
        price:900.00
    },
    {
        id: 22,
        name: 'Milk Coffee',
        image: 'coff3.jpg',
        price:100
    },
    {
        id: 23,
        name: 'Coffee',
        image: 'coff5.jpg',
        price: 200.00
    },
    {
        id: 24,
        name: 'Tea',
        image: 't.jpg',
        price:50.00
    },
    {
        id: 25,
        name: 'Bubble Tea',
        image: 'bt.jpg',
        price:350.00
    },
    {
        id: 26,
        name: 'Sweet Beverages',
        image: 'beve.jpg',
        price: 150.00
    },
    {
        id: 27,
        name: 'Sparkling Water',
        image: 'sw.jpg',
        price:100.00
    },
    {
        id: 28,
        name: 'Fruit Infused Water',
        image: 'fiw.jpg',
        price:250.00
    },
    {
        id: 29,
        name: 'Faluda',
        image: 'fa.jpg',
        price: 250.00
    },
    {
        id: 30,
        name: 'Stowberry Smoothy',
        image: 'sm1.jpg',
        price:300.00
    },
];
let listCarts  = [];
function initApp(){
    products.forEach((value, key) =>{
        let newDiv = document.createElement('div');
        newDiv.classList.add('item');
        newDiv.innerHTML = `
            <img src="${value.image}">
            <div class="title">${value.name}</div>
            <div class="price">${value.price.toLocaleString()}</div>
            <button onclick="addToCart(${key})">Add To Cart</button>`;
        list.appendChild(newDiv);
    })
}
initApp();
function addToCart(key){
    if(listCarts[key] == null){
        // copy product form list to list card
        listCarts[key] = JSON.parse(JSON.stringify(products[key]));
        listCarts[key].quantity = 1;
    }
    reloadCart();
}
function reloadCart(){
    listCart.innerHTML = '';
    let count = 0;
    let totalPrice = 0;
    listCarts.forEach((value, key)=>{
        totalPrice = totalPrice + value.price;
        count = count + value.quantity;
        if(value != null){
            let newDiv = document.createElement('li');
            newDiv.innerHTML = `
                <div><img src="${value.image}"/></div>
                <div>${value.name}</div>
                <div>${value.price.toLocaleString()}</div>
                <div>
                    <button onclick="changeQuantity(${key}, ${value.quantity - 1})">-</button>
                    <div class="count">${value.quantity}</div>
                    <button onclick="changeQuantity(${key}, ${value.quantity + 1})">+</button>
                </div>`;
                listCart.appendChild(newDiv);
        }
    })
    total.innerText = totalPrice.toLocaleString();
    quantity.innerText = count;
}
function changeQuantity(key, quantity){
    if(quantity == 0){
        delete listCarts[key];
    }else{
        listCarts[key].quantity = quantity;
        listCarts[key].price = quantity * products[key].price;
    }
    reloadCart();
}