<?php include("./config.php"); ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Contact Us</title>
  <style>
    body {
      font-family: 'Arial', sans-serif;
      margin: 0;
      padding: 0;
      background: linear-gradient(
        rgba(0,0,0,0.65),rgba(0,0,0,0.65),rgba(0,0,0,0.38),rgba(0,0,0,0)
    )
        ,url(home.JPG.jpg)no-repeat;
    background-size: cover;
    background-attachment: fixed;
    }
    .box{ width: 700px;
    height: 50px;
    float:right;
    border:1px solid none;
    font-weight:  500;
    }
    h1{
  font-size: 50px;
  color: #ffffff;
  font-weight: 300;
  text-align: center;

}   



.box ul li{
    width: 120px;
    float:left;
   /* font-size: 18px;*/
    margin:10px auto;
    text-align: center;
}

.box ul li a { text-decoration: none;
    color : darkgray;  }

    .box ul li :hover{background-color: rgb(2, 249, 55)};
    .box ul li a:hover{color : white;}
    
    .wd{
        width: 300px;
        height: 539px;
        background-color: black;
        opacity: 0.9;
        padding: 55px;
    }

    .wd h1{
        text-align: center;
        text-transform: uppercase;
        font-weight:100px ;

    }

    .Contact-header {
    height: 50vh;
    bottom: 50px;
    width: 100%;
   
    background-position: center;
    background-size: cover;
    text-align: center;
    color: #fff;
}

.h1 {
    margin-top: 100px;
    color: #ffffff;
}

/*contact us page*/

.location {
    width: 80%;
    margin: auto;
    padding: 80px 0;
}

.location iframe {
    width: 100%;
}

.contact-us {
    width: 80%;
    margin: auto;
}

.contact-col {
    flex-basis: 48%;
    margin-bottom: 30px
}

.contact-col div {
    display: flex;
    align-items: center;
    margin-bottom: 40px;
}

.contact-col div .fas {
    font-size: 28px;
    color: #F39C12;
    margin: 10px;
    margin-right: 30px
}

.contact-col div p {
    padding: 0;
    color: aquamarine;
}

.contact-col div h5 {
    font-size: 20px;
    margin-bottom: 5px;
    color: #ffffff;
    font-weight: 400;
}

.contact-col input,
.contact-col textarea {
    width: 100%;
    padding: 15px;
    margin-bottom: 17px;
    outline: none;
    border: 1px solid #ccc;
    border-radius: 10px;
    box-sizing: border-box;
}

  </style>
</head>
<body>
    <div class="top">
            
        <!---------------Navbar------------------------------------>
            <div class="box">
              <ul type="none">
                <li><a href="Home.html">Home</a></li>
                <li><a href="About.html">About us</a></li>
                <li><a href="Menu.html">Food Menu</a></li>
                <li><a href="login.html">Login</a></li>
                <!-- Add this line -->
                <li><a href="Contact.html">Contact us</a></li>
              </ul>
            </div>
        
            <h1>Contatc Us</h1>
       </div>
     


       <section class="location">

        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d6661.645484573672!2d79.91724097795124!3d6.88603944072159!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3ae25a082ec13591%3A0xae5d7cec4c69ff3f!2sParliament%20of%20Sri%20Lanka!5e0!3m2!1sen!2slk!4v1626775824911!5m2!1sen!2slk" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy"></iframe>

    </section>

    <section class="contact-us">
        <div class="row">
            <div class="contact-col">
                <div>
                    <i class="fas fa-home"></i>
                    <span>
                        <h5>Parliament Approach Rd</h5>
                        <p>Sri Jayawardenepura Kotte,Sri lanka</p>
                    </span>
                </div>

                <div>
                    <i class="fas fa-phone-alt"></i>
                    <span>
                        <h5>+94113652300</h5>
                        <p>Monday to Saturday, 10AM to 6PM</p>
                    </span>
                </div>

                <div>
                    <i class="fas fa-envelope"></i>
                    <span>
                        <h5>info@flavour.com</h5>
                        <p>Email us your quary</p>
                    </span>
                </div>
            </div>

            <div class="contact-col">

                <form action="con1.php" method="post">
                    <input type="text" name="name" placeholder="Enter your name" required>
                    <input type="text" name="email" placeholder="Enter your email" required>
                    <input type="text" name="subject" placeholder="Enter your subject" required>
                    <textarea rows="8" name="message" placeholder="Message" required></textarea>
                    <button type="submit" class="hero-btn2">Send Message</button>
                    <button type="reset" class="hero-btn2">Clear</button>
                </form>

            </div>
        </div>
    </section>


  

</body>
</html>