<?php include("./config.php"); ?>
<!DOCTYPE html>

<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8">
  
    <link rel="stylesheet" href="login.css">
    <!-- Fontawesome CDN Link -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
   </head>
<body>
    <div class="top">
            
        <!---------------Navbar------------------------------------>
            <div class="box">
              <ul type="none">
                <li><a href="Home.html">Home</a></li>
                <li><a href="About.html">About us</a></li>
                <li><a href="Menu.html">Food Menu</a></li>
                <li><a href="http://localhost/21it0483/images%20for%20ca_02/signup.php">Login</a></li>
                 <!-- Add this line -->
                <li><a href="Contact.html">Contact us</a></li>
              </ul>
            </div>
    </div>

  <div class="container">
    <input type="checkbox" id="flip">
    <div class="cover">
      <div class="front">
        <img src="home.JPG.jpg" alt="">
        <div class="text">
          <span class="text-1"> Please log in to your account to savor the delightful experience of our culinary offerings</span> <br> new adventure</span>
          <span class="text-2">Welcome back to Flavour Restaurant !</span>
        </div>
      </div>
      <div class="back">
        <img class="backImg" src="backImg.jpg" alt="">
        <div class="text">
          <span class="text-1">Complete miles of journey <br> with one step</span>
          <span class="text-2">Let's get started</span>
        </div>
      </div>
    </div>
    <!------------------------------------------------------------------------login------------------------------------------------->
    <div class="forms">
        <div class="form-content">
          <div class="login-form">
            <div class="title">Login</div>
          <form action="signin.php" method="post">
            <div class="input-boxes">
              <div class="input-box">
                <i class="fas fa-envelope"></i>
                <input type="text" placeholder="Enter your email" required name="email">
              </div>
              <div class="input-box">
                <i class="fas fa-lock"></i>
                <input type="password" placeholder="Enter your password" required name="password">
              </div>
              
              <a href="Checkout.html" >
              <div class="button input-box">
                <input type="submit" value="Sumbit">
              </div>
            </a>
              <div class="text sign-up-text">Don't have an account? <label for="flip">Sigup now</label></div>
            </div>
        </form>
      </div>

       <!------------------------------------------------------------------------signup------------------------------------------------->
        <div class="signup-form">
          <div class="title">Signup</div>
        <form action="add.php" method="post">
            <div class="input-boxes">
              <div class="input-box">
                <i class="fas fa-user"></i>
                <input type="text" placeholder="Enter your name" required name="name">
              </div>
              <div class="input-box">
                <i class="fas fa-envelope"></i>
                <input type="text" placeholder="Enter your email" required name="email">
              </div>
              <div class="input-box">
                <i class="fas fa-lock"></i>
                <input type="password" placeholder="Enter your password" required name="password">
              </div>
              <a href="http://localhost/21it0483/images%20for%20ca_02/Menu.php" class="button input-box">
              <button type="submit">Submit</button>
              </a>

              </div>
              <div class="text sign-up-text">Already have an account? <label for="flip">Login now</label></div>
            </div>
      </form>
    </div>
    </div>
    </div>
  </div>
</body>
</html>